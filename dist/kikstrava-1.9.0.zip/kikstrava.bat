@echo off
start "" "%~dp0KikStrava.exe"
